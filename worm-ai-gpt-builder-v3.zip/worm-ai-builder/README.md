# Worm AI — Full AI Website Builder

A mobile-friendly, static frontend with a Netlify Function that calls the Gemini API without exposing your API key in browser code.

## Features
- Gemini tool-calling agent that lists, reads, writes, deletes, and checks project files
- Editable HTML/CSS/JS files
- Sandboxed live preview
- Export generated project files as a ZIP
- Designed to work from an Android browser

## Deploy from an Android phone
1. Create a new GitHub repository and upload these project files while preserving the folder structure.
2. In Netlify, choose **Add new site / Import an existing project**, connect the repository, and deploy.
3. In the Netlify site dashboard, open **Project configuration → Environment variables**.
4. Add `GEMINI_API_KEY` with your Gemini API key. Do not paste the key into `app.js`, `index.html`, or any public file.
5. Optionally add `GEMINI_MODEL` with a model available to your API key. The default is `gemini-2.5-flash`.
6. Trigger a new deploy after setting the variables.
7. Open the deployed site and generate a small test page.

## Get a Gemini API key
Create one in Google AI Studio: https://aistudio.google.com/apikey

## Important security notes
- Never commit API keys to GitHub or place them in frontend JavaScript.
- API usage may incur charges or have quotas; review your Google AI Studio / Cloud account limits.
- The agent has a bounded tool-call loop and file-size limits, but this starter does not include user accounts, per-user rate limits, a database, or a production-grade abuse-prevention layer. Add authentication and rate limiting before sharing the public URL widely.
- Generated code can be unsafe or incorrect. Review it before publishing. The preview uses a sandboxed iframe, but generated code should still be treated as untrusted.
- Exported websites are the generated project source, not an automatically deployed separate site.
- The app requires internet access for Gemini requests and the JSZip CDN.

## Local testing
Use Netlify CLI in a development environment:
```sh
npm install -g netlify-cli
netlify dev
```
Set `GEMINI_API_KEY` in your local environment before running `netlify dev`.

## Project structure
```text
worm-ai-builder/
├── index.html
├── styles.css
├── app.js
├── netlify.toml
├── README.md
└── netlify/
    └── functions/
        └── generate.mjs
```

## Worm AI agent tools
The backend exposes bounded project tools to Gemini: list files, read a file, write a file, delete a non-essential file, run basic project checks, and finish with a summary. These actions operate only on the files sent for the current request; they do not have arbitrary server filesystem access and do not deploy projects automatically.

## Optional: enter your own key in the Worm AI page
The app includes a password field for a personal Gemini key. If `GEMINI_API_KEY` is configured in Netlify, the server-side key takes priority. Otherwise, the key entered in the page is sent to the Netlify Function over HTTPS for the current generation request and is not saved in browser storage or written to project files. It is held in page memory until you clear it or reload.
For best security, prefer Netlify Environment Variables and keep the deployed site private. Anyone who can use a public site may be able to consume your configured server key. Never paste a key into a public chat or commit it to GitHub.


## Worm AI GPT update
The key field in the website lets you paste your own Gemini API key. The key entered in the field takes priority over any `GEMINI_API_KEY` set in Netlify, which helps avoid an old server key overriding your current key. The key is kept in page memory only and sent to the Netlify Function over HTTPS for the generation request; it is not saved in browser storage or project files. Reloading the page clears it. Do not use a public/shared computer for private keys, and don't share your key.

Worm AI is designed to follow normal website requests closely without arbitrary design restrictions. It still must not generate harmful code such as malware, credential theft, or covert tracking.
