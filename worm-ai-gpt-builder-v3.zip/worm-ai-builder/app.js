const $ = (id) => document.getElementById(id);
const promptInput = $("promptInput"), generateBtn = $("generateBtn"), codeEditor = $("codeEditor");
const fileSelect = $("fileSelect"), previewFrame = $("previewFrame"), notice = $("notice");
let projectFiles = {}, currentFile = "index.html", busy = false, enteredApiKey = "";

promptInput.addEventListener("input", () => $("charCount").textContent = `${promptInput.value.length} / 12000`);
function tell(message, kind="info") { notice.textContent = message; notice.className = `notice show ${kind}`; }
function clearNotice() { notice.textContent = ""; notice.className = "notice"; }
$("apiKeyInput").addEventListener("input", () => {
  enteredApiKey = $("apiKeyInput").value.trim();
  $("keyStatus").textContent = enteredApiKey ? "A key is entered for this page session. It is not saved." : "No key entered in this page. The server key will be used if configured.";
});
$("toggleKeyBtn").addEventListener("click", () => {
  const field = $("apiKeyInput");
  field.type = field.type === "password" ? "text" : "password";
  $("toggleKeyBtn").textContent = field.type === "password" ? "Show" : "Hide";
});
$("clearKeyBtn").addEventListener("click", () => {
  enteredApiKey = "";
  $("apiKeyInput").value = "";
  $("apiKeyInput").type = "password";
  $("toggleKeyBtn").textContent = "Show";
  $("keyStatus").textContent = "Key cleared from this page session.";
});
function setBusy(value) { busy=value; generateBtn.disabled=value; generateBtn.innerHTML=value ? "⏳ Building…" : "<span>✦</span> Generate website"; }
function setEditorStatus(text) { $("editorStatus").textContent=text; }
function syncEditorToFile() { if (currentFile && Object.hasOwn(projectFiles,currentFile)) projectFiles[currentFile]=codeEditor.value; }
function fillFileSelect() {
  fileSelect.innerHTML="";
  Object.keys(projectFiles).forEach(name=>{ const o=document.createElement("option"); o.value=name;o.textContent=name;fileSelect.appendChild(o); });
  fileSelect.value=currentFile; fileSelect.disabled=!Object.keys(projectFiles).length;
  $("fileCount").textContent=`${Object.keys(projectFiles).length} file(s)`;
}
function renderPreview() {
  syncEditorToFile();
  const html = projectFiles["index.html"] || "<!doctype html><html><body><h1>Worm AI preview</h1></body></html>";
  const css = projectFiles["styles.css"] || "";
  const js = projectFiles["app.js"] || "";
  let output = html;
  // Put generated CSS and JS inline so preview works without a local web server.
  if (css) {
    if (/<\/head>/i.test(output)) output=output.replace(/<\/head>/i, `<style>${css.replace(/<\/style/gi,"<\\/style")}</style></head>`);
    else output=`<style>${css.replace(/<\/style/gi,"<\\/style")}</style>${output}`;
  }
  if (js) {
    const safeJs=js.replace(/<\/script/gi,"<\\/script");
    if (/<\/body>/i.test(output)) output=output.replace(/<\/body>/i, `<script>${safeJs}<\/script></body>`);
    else output+=`<script>${safeJs}<\/script>`;
  }
  previewFrame.srcdoc=output;
  $("refreshBtn").disabled=false;
  $("exportBtn").disabled=false;
  $("copyBtn").disabled=false;
  setEditorStatus("Preview updated");
}
fileSelect.addEventListener("change",()=>{syncEditorToFile();currentFile=fileSelect.value;codeEditor.value=projectFiles[currentFile]||"";});
$("applyCodeBtn").addEventListener("click",()=>{renderPreview();tell("Preview updated with your latest code.","info");});
$("refreshBtn").addEventListener("click",renderPreview);
$("copyBtn").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(codeEditor.value);tell("Code copied to clipboard.","info");}catch{tell("Clipboard access was blocked by the browser. Select the code and copy it manually.","error");}});
generateBtn.addEventListener("click", async()=>{
  clearNotice();
  const prompt=promptInput.value.trim();
  if(!prompt){tell("First describe the website you want Worm AI to build.","error");promptInput.focus();return;}
  setBusy(true);tell("Worm AI is creating your project. This can take a little while.","info");setEditorStatus("Generating…");
  try{
    const response=await fetch("/.netlify/functions/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,existingFiles:projectFiles,apiKey:enteredApiKey})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error||`Request failed (${response.status})`);
    let parsed=data.files;
    if(typeof parsed==="string") parsed=JSON.parse(parsed);
    if(!parsed || typeof parsed!=="object" || !parsed["index.html"]) throw new Error("The AI response did not contain index.html. Please try a more specific prompt.");
    projectFiles={};
    for(const [name,content] of Object.entries(parsed)){
      if(typeof content==="string" && !name.startsWith("/") && !name.includes("..") && /^[\w.-]+$/.test(name)) projectFiles[name]=content;
    }
    if(!projectFiles["index.html"]) throw new Error("The generated project was missing index.html.");
    currentFile="index.html";fillFileSelect();codeEditor.disabled=false;codeEditor.value=projectFiles[currentFile];
    $("applyCodeBtn").disabled=false;renderPreview();tell((data.summary ? data.summary + " " : "") + "Project is ready. Edit the code, update the preview, or export the ZIP.","info");
  }catch(error){tell(error.message||"Something went wrong. Check your Netlify function and Gemini API key.","error");setEditorStatus("Generation failed");}
  finally{setBusy(false);}
});
$("exportBtn").addEventListener("click",async()=>{
  syncEditorToFile();
  if(!Object.keys(projectFiles).length)return;
  if(!window.JSZip){tell("ZIP library could not load. Check your internet connection and reload the page.","error");return;}
  try{
    const zip=new JSZip();
    Object.entries(projectFiles).forEach(([name,content])=>zip.file(name,content));
    zip.file("README.txt","Worm AI generated project\n\nOpen index.html to inspect the website. For full functionality, serve it through a web server. Review all generated code before publishing.\n");
    const blob=await zip.generateAsync({type:"blob"});
    const url=URL.createObjectURL(blob), a=document.createElement("a");
    a.href=url;a.download="worm-ai-website.zip";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    tell("Project ZIP created. Check your Downloads folder.","info");
  }catch(e){tell("Could not export ZIP: "+e.message,"error");}
});
